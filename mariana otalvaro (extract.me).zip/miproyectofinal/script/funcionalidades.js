function veralerta(){
	alert("bienvenidos a nuestra página web muñecos magu aquí podrás encontrar lo que busques y necesites");
}
